image_file = "/carc/scratch/users/aalasand/workspace/LLAVA/geoguessr_images/Norway/canvas_1629934889.jpg"
from llava.model.builder import load_pretrained_model
from llava.mm_utils import get_model_name_from_path
from llava.eval.run_llava import eval_model
import sys

model_path = "liuhaotian/llava-v1.5-7b"
tokenizer, model, image_processor, context_len = load_pretrained_model(
    model_path=model_path,
    model_base=None,
    model_name=get_model_name_from_path(model_path)
)

prompt = "You are at the location of this image. Describe the environment in as much detail as you can so that the person you are describing it to can pinpoint your location on a world map. Describe the architectural style of buildings, the race/ethnicity of people, make/model of cars, and language on signs, if applicable."

args = type('Args', (), {
    "model_path": model_path,
    "model_base": None,
    "model_name": get_model_name_from_path(model_path),
    "query": prompt,
    "conv_mode": None,
    "image_file": image_file,
    "sep": ",",
    "temperature": 0,
    "top_p": None,
    "num_beams": 1,
    "max_new_tokens": 512
})()

model_output_file = open("output.txt", "w")
original_stdout = sys.stdout
sys.stdout = model_output_file
eval_model(args)
sys.stdout = original_stdout
model_output_file.close()
